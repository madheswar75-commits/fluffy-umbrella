package com.meshlink.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.meshlink.app.data.MessageStatus
import com.meshlink.app.data.local.entity.EmergencyMessageEntity
import com.meshlink.app.data.repository.MeshRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

class EmergencyViewModel(private val repository: MeshRepository) : ViewModel() {

    val history: StateFlow<List<EmergencyMessageEntity>> = repository.observeEmergencyHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val connectedPeerCount: StateFlow<Int> = repository.observeConnectedPeerCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    /**
     * Persists the alert as HIGH PRIORITY (real DB write) and hands it to
     * every connected peer. [onSent] fires only after the alert's row really
     * reaches SENT/DELIVERED/RELAYED — i.e. Nearby confirmed the transfer.
     * Otherwise [onNoRoute] fires: either no peer is connected, or no
     * transfer was confirmed within [CONFIRM_TIMEOUT_MS]. In both cases the
     * alert stays QUEUED/FAILED in the database and is retried automatically
     * when a peer connects (until it expires).
     */
    fun sendEmergency(content: String, onSent: () -> Unit, onNoRoute: () -> Unit) {
        if (content.isBlank()) return
        viewModelScope.launch {
            val alert = repository.sendEmergencyMessage(content.trim())
            if (repository.observeConnectedPeerCount().first() == 0) {
                onNoRoute()
                return@launch
            }
            val settled = withTimeoutOrNull(CONFIRM_TIMEOUT_MS) {
                repository.observeEmergency(alert.emergencyId)
                    .first { it != null && it.status != MessageStatus.QUEUED.name }
            }
            val confirmed = settled != null && settled.status != MessageStatus.FAILED.name
            if (confirmed) onSent() else onNoRoute()
        }
    }

    class Factory(private val repository: MeshRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = EmergencyViewModel(repository) as T
    }

    private companion object {
        const val CONFIRM_TIMEOUT_MS = 8_000L
    }
}
