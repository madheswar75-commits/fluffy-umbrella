package com.meshlink.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.meshlink.app.data.local.entity.EmergencyMessageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface EmergencyMessageDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: EmergencyMessageEntity)

    @Query("SELECT * FROM emergency_messages ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<EmergencyMessageEntity>>

    @Query("UPDATE emergency_messages SET status = :status WHERE emergencyId = :emergencyId")
    suspend fun updateStatus(emergencyId: String, status: String)

    /** Mirrors the underlying message's real transfer result onto the alert history row. */
    @Query("UPDATE emergency_messages SET status = :status WHERE messageId = :messageId")
    suspend fun updateStatusByMessageId(messageId: String, status: String)

    /** Only moves a row that is still waiting/failed — never downgrades DELIVERED/RELAYED. */
    @Query("UPDATE emergency_messages SET status = :status WHERE messageId = :messageId AND status IN ('QUEUED','FAILED')")
    suspend fun advanceFromPendingByMessageId(messageId: String, status: String)

    @Query("SELECT * FROM emergency_messages WHERE emergencyId = :emergencyId")
    fun observeById(emergencyId: String): Flow<EmergencyMessageEntity?>
}
