package com.meshlink.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.meshlink.app.data.local.entity.MessageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {

    /**
     * OnConflictStrategy.IGNORE on the messageId primary key means a message
     * that has already been stored can never be inserted a second time —
     * this IS the duplicate-prevention mechanism required by spec section 5
     * ("Use unique IDs to prevent duplicate messages") and section 6
     * ("Prevent duplicate forwarding using messageId"). Returns -1 when the
     * row already existed, which callers can use to detect a no-op insert.
     */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(message: MessageEntity): Long

    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY timestamp ASC")
    fun observeMessagesForConversation(conversationId: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE messageId = :messageId")
    suspend fun getById(messageId: String): MessageEntity?

    @Query("SELECT EXISTS(SELECT 1 FROM messages WHERE messageId = :messageId)")
    suspend fun exists(messageId: String): Boolean

    @Query("UPDATE messages SET status = :status WHERE messageId = :messageId")
    suspend fun updateStatus(messageId: String, status: String)

    /**
     * Atomic, race-free transitions. SENT may only follow QUEUED/FAILED (so a
     * late "transfer succeeded" callback can never downgrade DELIVERED), and
     * DELIVERED applies only to OUR outgoing copy (so an ack can never
     * overwrite the status of a message we merely received or relayed).
     * Each returns the number of rows changed (0 = the guard refused it).
     */
    @Query("UPDATE messages SET status = 'SENT' WHERE messageId = :messageId AND isOutgoing = 1 AND status IN ('QUEUED','FAILED')")
    suspend fun markSentIfPending(messageId: String): Int

    @Query("UPDATE messages SET status = 'DELIVERED' WHERE messageId = :messageId AND isOutgoing = 1")
    suspend fun markDeliveredIfOutgoing(messageId: String): Int

    /** A transfer failure must not overwrite SENT/DELIVERED that a racing callback already recorded. */
    @Query("UPDATE messages SET status = 'FAILED' WHERE messageId = :messageId AND isOutgoing = 1 AND status = 'QUEUED'")
    suspend fun markFailedIfQueued(messageId: String): Int

    @Query("SELECT COUNT(*) FROM messages WHERE isOutgoing = 1 AND status = :status")
    fun observeCountByStatus(status: String): Flow<Int>

    /** Used when a peer just connected, to flush anything that queued up while offline. */
    @Query("SELECT * FROM messages WHERE conversationId = :conversationId AND status = 'QUEUED' AND isOutgoing = 1")
    suspend fun getQueuedForConversation(conversationId: String): List<MessageEntity>

    /**
     * Everything still worth (re)sending to one peer: not yet handed off
     * (QUEUED) or whose transfer failed (FAILED) but has not expired. Expired
     * rows are excluded so a TTL-expired FAILED message is never resurrected.
     */
    @Query("SELECT * FROM messages WHERE conversationId = :conversationId AND status IN ('QUEUED','FAILED') AND isOutgoing = 1 AND expiryTime > :now")
    suspend fun getRetryableForConversation(conversationId: String, now: Long): List<MessageEntity>

    /** Same, for broadcast (emergency) messages that have no conversation. */
    @Query("SELECT * FROM messages WHERE receiverId = :receiverId AND status IN ('QUEUED','FAILED') AND isOutgoing = 1 AND expiryTime > :now")
    suspend fun getRetryableByReceiver(receiverId: String, now: Long): List<MessageEntity>

    /** Used by the periodic TTL sweep so a message can't stay QUEUED/circulating forever. */
    @Query("SELECT * FROM messages WHERE status = 'QUEUED' AND isOutgoing = 1")
    suspend fun getAllQueuedOutgoing(): List<MessageEntity>
}
