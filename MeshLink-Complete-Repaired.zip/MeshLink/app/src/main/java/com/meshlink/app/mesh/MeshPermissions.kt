package com.meshlink.app.mesh

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * The exact runtime permissions MeshLink needs to discover/connect to
 * nearby peers, and why — per spec section 8: request only what's needed
 * for the chosen technology (Nearby Connections, which uses BLE + classic
 * Bluetooth + Wi-Fi under the hood), and explain each one.
 *
 * No INTERNET permission is requested anywhere in this app — it is not
 * needed for local device-to-device discovery/connection/transfer, and
 * requesting it would contradict the offline-first requirement.
 */
object MeshPermissions {

    /** The set that MUST be granted for scanning to work, chosen by API level. */
    fun required(): Array<String> = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_ADVERTISE,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.NEARBY_WIFI_DEVICES
        )
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_ADVERTISE,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        else -> arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION
        )
    }

    /**
     * What to pass to the system permission dialog. On Android 12 / 12L
     * (API 31-32) a request for ACCESS_FINE_LOCATION must be accompanied by
     * ACCESS_COARSE_LOCATION in the same request, otherwise the system does
     * not honour it. COARSE is therefore requested but NOT required: a user
     * who picks "approximate" for it still counts as granted for the
     * must-have set above only if FINE was granted too.
     */
    fun toRequest(): Array<String> =
        if (Build.VERSION.SDK_INT in Build.VERSION_CODES.S..Build.VERSION_CODES.S_V2) {
            required() + Manifest.permission.ACCESS_COARSE_LOCATION
        } else {
            required()
        }

    fun missing(context: Context): List<String> = required().filter { permission ->
        ContextCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED
    }

    fun hasAll(context: Context): Boolean = missing(context).isEmpty()

    /**
     * True when at least one missing permission can no longer be asked for
     * through the system dialog (the user chose "don't ask again", or denied
     * twice) — the only way forward is the app's system settings page.
     * Only meaningful AFTER a request has just been denied.
     */
    fun isPermanentlyDenied(context: Context): Boolean {
        val activity = context.findActivity() ?: return false
        return missing(context).any { permission ->
            !ActivityCompat.shouldShowRequestPermissionRationale(activity, permission)
        }
    }

    fun openAppSettings(context: Context) {
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.fromParts("package", context.packageName, null)
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    private fun Context.findActivity(): Activity? {
        var current: Context? = this
        while (current is ContextWrapper) {
            if (current is Activity) return current
            current = current.baseContext
        }
        return null
    }

    /** Shown in-app so the person knows exactly why each permission is asked for. */
    fun rationale(permission: String): String = when (permission) {
        Manifest.permission.BLUETOOTH_SCAN ->
            "Bluetooth scan — to discover nearby MeshLink devices."
        Manifest.permission.BLUETOOTH_ADVERTISE ->
            "Bluetooth advertise — so nearby MeshLink devices can discover this phone."
        Manifest.permission.BLUETOOTH_CONNECT ->
            "Bluetooth connect — to open a direct link with a nearby MeshLink device."
        Manifest.permission.NEARBY_WIFI_DEVICES ->
            "Nearby Wi-Fi devices — for local Wi-Fi-based discovery/transfer (no router or internet involved)."
        Manifest.permission.ACCESS_FINE_LOCATION ->
            "Location — required by Android on this OS version for Bluetooth/Wi-Fi peer discovery to " +
                "function at all. MeshLink does not read GPS location or track where you are."
        Manifest.permission.ACCESS_COARSE_LOCATION ->
            "Approximate location — Android asks for it together with location on this OS version."
        else -> "Required for offline device-to-device communication."
    }
}
