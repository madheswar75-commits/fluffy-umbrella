package com.meshlink.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.meshlink.app.data.ServiceLocator
import com.meshlink.app.navigation.MeshLinkNavGraph
import com.meshlink.app.ui.theme.MeshLinkTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MeshLinkTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MeshLinkNavGraph()
                }
            }
        }
    }

    override fun onDestroy() {
        // Only when the app is really being closed (back out / swipe away),
        // NOT on rotation or other configuration changes: stop discovery and
        // advertising and close every link so nothing keeps radios busy or
        // leaves a stale "Connected" behind. (There is no foreground service
        // yet, so background operation is not supported — see README.)
        if (isFinishing) {
            ServiceLocator.provideRepository(this).stopAllTransport()
        }
        super.onDestroy()
    }
}
