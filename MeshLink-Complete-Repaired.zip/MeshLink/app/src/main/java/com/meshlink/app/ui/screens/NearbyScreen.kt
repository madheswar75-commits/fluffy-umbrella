package com.meshlink.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.meshlink.app.data.DemoData
import com.meshlink.app.data.MeshStatus
import com.meshlink.app.data.PeerConnectionState
import com.meshlink.app.data.PeerDeviceUi
import com.meshlink.app.mesh.MeshPermissions
import com.meshlink.app.viewmodel.NearbyViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NearbyScreen(viewModel: NearbyViewModel) {
    val context = LocalContext.current
    val meshStatus by viewModel.meshStatus.collectAsState()
    val scanning by viewModel.scanning.collectAsState()
    val transportError by viewModel.transportError.collectAsState()
    val realPeers by viewModel.peers.collectAsState()
    val missingPermissions = rememberMissingPermissions()
    var permissionDenied by remember { mutableStateOf(false) }
    var permanentlyDenied by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        // Judge by the REAL permission state, not by the result map: on
        // Android 12/12L the request also contains COARSE location, which the
        // person may legitimately decline while still granting what scanning needs.
        if (MeshPermissions.hasAll(context)) {
            permissionDenied = false
            permanentlyDenied = false
            viewModel.startScan()
        } else {
            // Real denial handling: never proceed as if permissions were
            // granted, and never crash — just surface it.
            permissionDenied = true
            permanentlyDenied = MeshPermissions.isPermanentlyDenied(context)
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Nearby") }) }
    ) { padding ->
        // ONE scrolling list for the whole screen. (Two lists stacked in a Column
        // let the first one take all the height and push the Demo section off-screen.)
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
              Column {
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        if (scanning) {
                            viewModel.stopScan()
                        } else if (MeshPermissions.hasAll(context)) {
                            permissionDenied = false
                            viewModel.startScan()
                        } else {
                            permissionLauncher.launch(MeshPermissions.toRequest())
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (scanning) "Stop Scan" else "SCAN")
                }
              }
            }

            if (transportError != null) {
                item {
                    ErrorCard(message = transportError.orEmpty(), onDismiss = viewModel::dismissError)
                }
            }

            if (permissionDenied && missingPermissions.isNotEmpty()) {
                item {
                    PermissionDeniedCard(
                        missing = missingPermissions,
                        permanentlyDenied = permanentlyDenied,
                        onRetry = { permissionLauncher.launch(MeshPermissions.toRequest()) },
                        onOpenSettings = { MeshPermissions.openAppSettings(context) }
                    )
                }
            }

            if (scanning) {
                item {
                  Column {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Discovering and advertising to nearby MeshLink devices over Bluetooth/Wi-Fi \u2014 " +
                            "no internet involved.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                  }
                }
            } else if (meshStatus == MeshStatus.CONNECTED) {
                item {
                    Text(
                        "Connected. Scanning is stopped; existing connections stay open. " +
                            "Tap SCAN to look for more devices.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            }

            item {
                Text(
                    "Real Devices",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            if (realPeers.isEmpty()) {
                item {
                    EmptyState(
                        if (scanning)
                            "Scanning\u2026 no MeshLink peers found yet. Make sure the other phone " +
                                "also has MeshLink open with Nearby scanning turned on and is within " +
                                "Bluetooth/Wi-Fi range."
                        else
                            "Tap SCAN to discover real nearby MeshLink devices over Bluetooth/Wi-Fi."
                    )
                }
            } else {
                items(realPeers, key = { it.id }) { peer ->
                    RealPeerRow(
                        peer = peer,
                        onConnect = { viewModel.connect(peer.id) },
                        onDisconnect = { viewModel.disconnect(peer.id) }
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.padding(top = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Demo Peers", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.width(8.dp))
                    StatusChip("DEMO DATA", MaterialTheme.colorScheme.error)
                }
            }
            items(DemoData.demoPeers, key = { it.id }) { peer ->
                PeerRow(peer)
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun ErrorCard(message: String, onDismiss: () -> Unit) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text("Problem", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(6.dp))
            Text(message, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(4.dp))
            Text(
                "If this mentions Bluetooth or location, check that Bluetooth is on (and, on older " +
                    "Android versions, Location is on), then tap SCAN again.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.outline
            )
            TextButton(onClick = onDismiss) { Text("Dismiss") }
        }
    }
}

@Composable
private fun PermissionDeniedCard(
    missing: List<String>,
    permanentlyDenied: Boolean,
    onRetry: () -> Unit,
    onOpenSettings: () -> Unit
) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text("Permission needed", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            missing.forEach { permission ->
                Text(
                    "\u2022 " + MeshPermissions.rationale(permission),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "MeshLink can't discover or connect to nearby devices without these. " +
                    "Nothing else in the app is affected - Home, Chat, and Settings still work.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.outline
            )
            Spacer(Modifier.height(8.dp))
            if (permanentlyDenied) {
                Text(
                    "Android will not show the permission prompt again. Open the app's " +
                        "settings page, choose Permissions, and allow them there.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline
                )
                TextButton(onClick = onOpenSettings) { Text("Open app settings") }
            } else {
                TextButton(onClick = onRetry) { Text("Grant permissions") }
            }
        }
    }
}

@Composable
private fun RealPeerRow(peer: PeerDeviceUi, onConnect: () -> Unit, onDisconnect: () -> Unit) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(peer.displayName, style = MaterialTheme.typography.titleMedium)
                // Short ID so two phones with the same name can still be told apart.
                Text(
                    "ID " + peer.id.replace("-", "").take(4).uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline
                )
                Spacer(Modifier.height(4.dp))
                StatusChip(labelForPeerState(peer.state), colorForPeerState(peer.state))
            }

            when (peer.state) {
                PeerConnectionState.AVAILABLE -> TextButton(onClick = onConnect) { Text("CONNECT") }
                PeerConnectionState.CONNECTED -> TextButton(onClick = onDisconnect) { Text("DISCONNECT") }
                PeerConnectionState.CONNECTING -> CircularProgressIndicator(modifier = Modifier.size(20.dp))
                PeerConnectionState.DISCONNECTED -> TextButton(onClick = onConnect) { Text("RECONNECT") }
            }
        }
    }
}

@Composable
private fun PeerRow(peer: PeerDeviceUi) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(peer.displayName, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.width(6.dp))
                    StatusChip("DEMO", MaterialTheme.colorScheme.error)
                }
                Spacer(Modifier.height(4.dp))
                StatusChip(labelForPeerState(peer.state), colorForPeerState(peer.state))
            }

            when (peer.state) {
                PeerConnectionState.AVAILABLE -> TextButton(onClick = { }) { Text("CONNECT") }
                PeerConnectionState.CONNECTED -> TextButton(onClick = { }) { Text("DISCONNECT") }
                PeerConnectionState.CONNECTING -> CircularProgressIndicator(modifier = Modifier.size(20.dp))
                PeerConnectionState.DISCONNECTED -> TextButton(onClick = { }) { Text("RETRY") }
            }
        }
    }
}
