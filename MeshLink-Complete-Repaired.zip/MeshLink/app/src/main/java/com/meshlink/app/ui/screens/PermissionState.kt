package com.meshlink.app.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.meshlink.app.mesh.MeshPermissions

/**
 * Re-reads the REAL permission state every time the app returns to the
 * foreground (e.g. back from the system settings page), so the UI never
 * keeps showing "permission needed" after the person has granted it there.
 * Returns the list of required permissions still missing.
 */
@Composable
fun rememberMissingPermissions(): List<String> {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var resumeCount by remember { mutableIntStateOf(0) }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) resumeCount++
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Keyed on resumeCount so it is re-read after every return to the app.
    return remember(resumeCount) { MeshPermissions.missing(context) }
}
