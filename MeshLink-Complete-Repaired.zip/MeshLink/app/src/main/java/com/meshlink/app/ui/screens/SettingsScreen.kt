package com.meshlink.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.meshlink.app.mesh.MeshPermissions
import com.meshlink.app.mesh.MeshTransportManager
import com.meshlink.app.viewmodel.SettingsViewModel

private const val NOT_IMPLEMENTED = "DEMO / NOT YET IMPLEMENTED"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: SettingsViewModel) {
    val context = LocalContext.current
    val user by viewModel.currentUser.collectAsState()
    val missingPermissions = rememberMissingPermissions()
    var showRenameDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Settings") }) }
    ) { padding ->
        LazyColumn(modifier = Modifier.padding(padding).fillMaxSize()) {
            item { SectionHeader("Profile") }
            item {
                ListItem(
                    headlineContent = { Text("Device name") },
                    supportingContent = {
                        Text(
                            (user?.displayName ?: "Loading…") +
                                " — this is the name other MeshLink phones see. " +
                                "Give each phone a different name."
                        )
                    },
                    trailingContent = {
                        TextButton(onClick = { showRenameDialog = true }, enabled = user != null) { Text("EDIT") }
                    }
                )
            }
            item {
                ListItem(
                    headlineContent = { Text("This phone") },
                    supportingContent = {
                        val u = user
                        Text(
                            if (u == null) "…"
                            else "${u.deviceName} · ID ${shortId(u.userId)} (also shown next to your name on other phones)"
                        )
                    }
                )
            }

            item { SectionHeader("Appearance") }
            item {
                ListItem(
                    headlineContent = { Text("Dark mode") },
                    supportingContent = { Text(NOT_IMPLEMENTED) },
                    trailingContent = { Switch(checked = false, onCheckedChange = null, enabled = false) }
                )
            }

            item { SectionHeader("Privacy & Security") }
            item { ListItem(headlineContent = { Text("Privacy") }, supportingContent = { Text("Who can discover and message this device — $NOT_IMPLEMENTED") }) }
            item { ListItem(headlineContent = { Text("Security") }, supportingContent = { Text("Device identity & message authentication — Phase 7, $NOT_IMPLEMENTED. Incoming connections are currently auto-accepted.") }) }
            item {
                ListItem(
                    headlineContent = { Text("Permissions") },
                    supportingContent = {
                        Text(
                            if (missingPermissions.isEmpty()) "All permissions needed for Nearby scanning are granted."
                            else "Missing: " + missingPermissions.joinToString { it.substringAfterLast('.') }
                        )
                    },
                    trailingContent = {
                        if (missingPermissions.isNotEmpty()) {
                            TextButton(onClick = { MeshPermissions.openAppSettings(context) }) { Text("OPEN SETTINGS") }
                        }
                    }
                )
            }
            item { ListItem(headlineContent = { Text("Notifications") }, supportingContent = { Text("Alerts for new and emergency messages — $NOT_IMPLEMENTED") }) }

            item { SectionHeader("Developer") }
            item {
                ListItem(
                    headlineContent = { Text("Demo mode") },
                    supportingContent = { Text("The Nearby tab always lists clearly-labelled DEMO DATA peers; this switch does nothing yet — $NOT_IMPLEMENTED") },
                    trailingContent = { Switch(checked = true, onCheckedChange = null, enabled = false) }
                )
            }

            item { SectionHeader("About") }
            item {
                ListItem(
                    headlineContent = { Text("About MeshLink") },
                    supportingContent = {
                        Text(
                            "Phases 1–3 (UI, local database, real Nearby discovery and " +
                                "messaging) with the post-audit repairs. Offline messaging over " +
                                "Bluetooth/Wi-Fi — no cloud service for core messaging. Relay of " +
                                "ordinary messages, retry policy, security and AI classification " +
                                "are later phases."
                        )
                    }
                )
            }
        }
    }

    if (showRenameDialog) {
        RenameDialog(
            initial = user?.displayName.orEmpty(),
            onDismiss = { showRenameDialog = false },
            onSave = { name ->
                viewModel.rename(name)
                showRenameDialog = false
            }
        )
    }
}

private fun shortId(userId: String): String = userId.replace("-", "").take(4).uppercase()

@Composable
private fun RenameDialog(initial: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    val max = MeshTransportManager.MAX_DISPLAY_NAME_LENGTH
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Device name") },
        text = {
            Column {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it.take(max) },
                    singleLine = true,
                    label = { Text("Name shown to nearby phones") },
                    supportingText = { Text("${text.length}/$max") }
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "If you are scanning, the new name is advertised right away. " +
                        "Phones that already saved your old name update when they next discover you.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(text) }, enabled = text.isNotBlank()) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        title,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 4.dp)
    )
}
