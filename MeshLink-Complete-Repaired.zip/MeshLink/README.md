# MeshLink — Offline Emergency Messenger

**Status: Phases 1–3 of 8, plus the post-audit repair pass.** Phase 4 has not been started.

> **Build status: NOT VERIFIED.** No Gradle/Android build has been run on this code
> (the environment that produced it has no Android SDK and no access to Google/Maven
> hosts). It has only been syntax-parsed and cross-checked by script. Open it in
> Android Studio, build it, and treat the first compile as the real test. Nothing in
> this project has been run on a phone.

## What it is

Kotlin · Jetpack Compose · Material 3 · Room · Coroutines · ViewModel/Repository ·
Google Nearby Connections (`play-services-nearby`, `P2P_CLUSTER`). Discovery and
transfer happen directly between phones over Bluetooth/Wi-Fi; no internet, server,
Firebase, WhatsApp or Telegram is involved in core messaging. Requires Google Play
services on both phones.

## How message states work (after the repair pass)

| State | Meaning — the only way to reach it |
|---|---|
| `QUEUED` | Saved in Room. Not yet confirmed as transferred. A message stays QUEUED even while it is being handed to Nearby. |
| `SENT` | Nearby reported `PayloadTransferUpdate.SUCCESS` for that payload. **Only** this event sets SENT. |
| `DELIVERED` | The receiving phone stored the message and sent an app-level ack back. Applied only to our own outgoing copy. |
| `RELAYED` | An emergency broadcast received here was handed on to another connected peer (handed-off, not confirmed). |
| `FAILED` | Transfer failed/was canceled (retried on the next connection until it expires), or the TTL passed (24 h normal, 6 h emergency; never retried). |

"Connected" is shown only for a peer with a real, established Nearby link. Stored peer
states are reset to Disconnected at every app start (links never survive a restart),
and everything is torn down when the app is really closed.

## What the repair pass changed

- **Gradle wrapper:** `gradle/wrapper/gradle-wrapper.jar`, `gradlew` and `gradlew.bat`
  generated with Gradle's own `gradle wrapper` task (distribution 8.7).
- **Permissions:** `ACCESS_COARSE_LOCATION` declared and requested together with fine
  location on Android 12/12L (API 31–32), as Android requires. "Granted" is judged from
  the real permission state. A permanently denied permission shows an *Open app
  settings* button; permission state refreshes when you return to the app.
- **Device name:** Settings → *Device name* is editable (max 20 chars) and is the name
  advertised to other phones. New installs get a distinct default (`MeshLink-XXXX`),
  and the old shared default ("You") is replaced. Nearby also shows a short ID per peer.
- **Connection state:** the transport keeps its own set of really-connected peers;
  `send()` refuses anything else, and a peer being lost from discovery no longer drops
  a live connection's address. The mesh status comes from that live set.
- **Sending/queuing:** no message or emergency alert is marked SENT before Nearby
  confirms the transfer. Queued and failed (not expired) messages and emergency alerts
  are re-sent whenever a peer connects.
- **Discovery errors:** start failures are reported (the scan state follows what is
  really running) and shown on the Nearby screen; double-start is ignored.
- **Cleanup/lifecycle:** *Stop Scan* stops discovery/advertising and keeps existing
  links; closing the app stops everything and closes all connections.
- **UI:** Nearby is one scrolling list (the Demo section can no longer be pushed
  off-screen); Settings controls that do nothing are disabled and labelled
  "DEMO / NOT YET IMPLEMENTED"; Settings' *Permissions* row shows real status.
- **Compile errors found by review** (could not be confirmed by a compiler):
  `SettingsScreen.kt` used `dp` without importing it, and `MeshLinkNavGraph.kt`
  used `Modifier.padding` without importing it. Both are fixed.
- Emergency screen: lazy-list item with several root composables wrapped in a `Column`.

## Known limitations (not hidden)

- **No way to start a 1:1 chat with a discovered peer yet.** Home's "+" creates a
  *manual* test peer with its own random ID, so messages to it can never reach a real
  phone, and a received 1:1 message needs an existing conversation. Real transfer can
  currently be exercised end-to-end through the **Emergency** screen only. A "Message
  this peer" button on a connected Nearby entry is the natural fix.
- A received emergency broadcast appears in the **Emergency tab history**, not on Home.
- An emergency alert is sent only to peers connected at that moment or when they
  connect later *while it is still QUEUED/FAILED*; once it is SENT to one peer it is
  not re-sent to a peer that connects afterwards.
- Connections are auto-accepted (no pairing UI, no authentication) — Phase 7.
- Works only while the app is open; there is no foreground service. Discovery and
  advertising have no timeout (battery).
- Only emergency broadcasts are relayed; ordinary multi-hop relay is Phase 5. The
  topology drawing on the Mesh tab is an illustration, labelled as such.
- Dark mode, Demo-mode switch, Privacy, Notifications are not implemented (labelled).
- Needs Google Play services (not a bare emulator image).
- Whether Android needs the Location *toggle* on for BLE discovery on older versions is
  unverified; the in-app error card mentions it.
- Nearby's documentation lists `ACCESS_COARSE_LOCATION` only up to API 28 and fine
  location up to API 31; this project additionally declares COARSE up to 32 and keeps
  FINE up to 32, following Android's runtime rule for API 31–32.

## Build

1. Open the `MeshLink/` folder in Android Studio (Koala 2024.1+ / JDK 17) and sync
   (internet needed the first time).
2. Or from a terminal: `./gradlew assembleDebug`
3. APK: `app/build/outputs/apk/debug/app-debug.apk`

## Two-phone testing

See the instructions delivered with this build (also summarised here).

1. Two real Android phones with Google Play services; Bluetooth and Wi-Fi on; install
   on both.
2. **Settings → Device name:** give the phones different names (e.g. "Phone A",
   "Phone B"). Confirm the name shows after you reopen the app.
3. **Nearby → SCAN** on both. Grant permissions. If you deny twice, use *Open app
   settings*. Expected: SCAN becomes *Stop Scan* only once scanning really started; an
   error card appears if it didn't (e.g. Bluetooth off).
4. Within seconds each phone lists the other under **Real Devices** as *Available*,
   with the name and a short ID.
5. Tap **CONNECT** on one phone → *Connecting…* → *Connected* on both.
6. **Emergency** on Phone A: send an alert. Expected: *TRANSFER CONFIRMED*; Phone B
   shows it in its Emergency history; Phone A's history moves SENT → DELIVERED.
7. Tap **DISCONNECT**; send another emergency alert. Expected: *NOT SENT — QUEUED
   LOCALLY*, history shows QUEUED. Reconnect: it should be re-sent and become SENT.
8. Turn Bluetooth off on Phone B mid-session; Phone A must stop showing it Connected.
9. Force-stop the app on Phone A and reopen: no peer may still show Connected.
10. Capture `adb logcat -s MeshTransportManager MeshRepository` on both for failures.

## Not implemented yet

| Missing | Phase |
|---|---|
| Multi-hop relay for ordinary 1:1 messages | 5 |
| Explicit retry policy/UI polish | 6 |
| Pairing confirmation, identity, authentication, encryption | 7 |
| AI emergency classification | 8 |
| "Message this peer" shortcut from Nearby | small add, on request |
